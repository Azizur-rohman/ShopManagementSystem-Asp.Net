﻿var deps = [];
var app = angular.module('myApp', deps);